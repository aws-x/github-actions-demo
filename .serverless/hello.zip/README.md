# github-workflow-nodejs-tests

![example workflow](https://github.com/aws-x/github-actions-demo/actions/workflows/node.js.yml/badge.svg)

<!--Code for this [video](https://youtu.be/9KVCxMrshIk).-->
